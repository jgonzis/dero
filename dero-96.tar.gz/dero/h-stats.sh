. /hive/miners/custom/dero/h-manifest.conf

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
