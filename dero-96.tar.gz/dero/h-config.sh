#!/usr/bin/env bash

. /hive/miners/custom/CMiner/h-manifest.conf

  	local MINER_CONFIG="/hive/miners/custom/dero/dero.conf"
 	 mkfile_from_symlink "$MINER_CONFIG"

     local conf=" --daemon-rpc-address=dero.spanishminers.com:11100"
     local wallet="--wallet ${CUSTOM_TEMPLATE}"

 	 conf+=" ${pool} ${wallet}"

  	[[ -n $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

   	echo "$conf" > "$MINER_CONFIG"


