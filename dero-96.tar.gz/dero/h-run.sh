#!/usr/bin/env bash

cd /hive/miners/custom/dero/

. h-manifest.conf

[[ ! -e /hive/miners/custom/dero/dero.conf ]] && echo "No config file found, exiting" && exit 1

dos2unix dero.conf

./dero $(<dero.conf)  $@ 2>&1 | tee $CUSTOM_LOG_BASENAME

